# AngKor Mall Project

This is a full e-commerce project with frontend, admin panel, and backend.