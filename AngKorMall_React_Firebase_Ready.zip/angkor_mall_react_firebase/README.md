
AngKor Mall - React + Firebase (Ready-to-deploy ZIP)
---------------------------------------------------

What's inside:
- frontend/       -> React frontend source (placeholder) and build (static) ready for Firebase
- admin/          -> React admin panel (placeholder) and build (static) ready for Firebase
- firebase.json   -> Hosting configuration (serves frontend and admin)
- .firebaserc     -> Firebase project alias (default: angkor-mall)
- README.md       -> This file

IMPORTANT: This ZIP contains **pre-built static files** (frontend/build and admin/build)
so you can deploy immediately to Firebase Hosting without running npm build if you prefer.
If you want to edit source, use the files in frontend/src and admin/src and run npm install/build.

Google Maps API Key: INCLUDED (as requested)
Key inserted in the built pages for demo:
    AIzaSyBzJUj2O15cTOdEtnXV0w3IhRhJOfQrgsU

How to deploy to Firebase (quick):
1) Install Firebase CLI on your PC or Termux:
   npm install -g firebase-tools

2) Login to Firebase with the Google account that has access to your Firebase project:
   firebase login

3) (Optional) If you haven't created a Firebase project, create one at:
   https://console.firebase.google.com
   Note your Project ID (e.g. angkor-mall). Add your account as Owner.

4) In this folder, set the Firebase project id (or use firebase use --add):
   firebase use --add
   (choose the project corresponding to the project id)

5) Deploy (this will publish frontend at root and admin at /admin):
   firebase deploy --only hosting

6) After deploy, you'll see hosting URL(s), e.g.:
   https://<PROJECT_ID>.web.app
   The admin will be reachable at https://<PROJECT_ID>.web.app/admin

Local preview:
- You can serve the built static files locally (no Node required) with a static server like 'serve':
  npm install -g serve
  serve -s frontend/build -l 5000
  and visit http://localhost:5000

Notes about Maps API key:
- For security, restrict the API key in Google Cloud Console to:
  - Application restriction: HTTP referrers (web sites)
  - Add: https://<PROJECT_ID>.web.app/* and http://localhost:3000/*
- Enabled APIs recommended: Maps JavaScript API, Places API, Geocoding API, Directions API

If you want, I can:
- Provide an APK build (Android) later
- Help you run the deploy step-by-step over a call or guide
- Modify source files to change texts, logo, or add real backend connectivity

Enjoy!
